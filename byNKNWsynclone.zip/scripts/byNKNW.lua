warn'Credits'
wait(1)
print'byNKWN'